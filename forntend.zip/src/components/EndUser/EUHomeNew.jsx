import React from "react";

const EUHomeNew = () => {
    return (
        <div>
            <h1>Home Page(End User)</h1>
        </div>
    );
}

export default EUHomeNew;