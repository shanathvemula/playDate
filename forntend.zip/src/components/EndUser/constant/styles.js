export const COLORS = {
  _primary: "#0F78D8",
  _green: "#81811D",
};
