export const routesLink = {
  HOME_SCREEN: "/",
  BOOK_SCREEN: "/booking",
  BOOKING_SCREEN: "/booking/proceed",
};
